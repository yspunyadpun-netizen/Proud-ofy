const MODEL = "gemini-2.5-flash";
const ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models";

const SCHEMA = {
  type: "OBJECT",
  properties: {
    meal_name: { type: "STRING" },
    note: { type: "STRING" },
    items: {
      type: "ARRAY",
      items: {
        type: "OBJECT",
        properties: {
          name: { type: "STRING" },
          quantity: { type: "STRING" },
          grams: { type: "NUMBER" },
          calories: { type: "NUMBER" },
          protein: { type: "NUMBER" },
          carbs: { type: "NUMBER" },
          fat: { type: "NUMBER" }
        },
        required: ["name", "quantity", "grams", "calories", "protein", "carbs", "fat"]
      }
    }
  },
  required: ["meal_name", "items"]
};

const RULES = `حدد كل طبق أو عنصر غذائي، وقدّر الكمية بالجرام أو بالحصة. احسب السعرات والبروتين والكربوهيدرات والدهون لكل عنصر بشكل تقديري واقعي. اكتب أسماء الأطباق بالعربية الفصحى المبسطة واجعل اسم الوجبة وصفاً قصيراً. إذا لم تكن الصورة أو الكلمات تصف طعاماً، أعد عنصراً واحداً باسم "غير محدد" وقيم صفرية واشرح ذلك في note.`;

export async function onRequestPost({ request, env }) {
  try {
    if (!env.GEMINI_API_KEY) {
      return Response.json({ error: "مفتاح Gemini غير مضبوط في Cloudflare." }, { status: 500 });
    }
    const body = await request.json();
    const description = typeof body.text === "string" ? body.text.trim().slice(0, 500) : "";
    const note = typeof body.note === "string" ? body.note.slice(0, 300) : "";
    const imageData = typeof body.image_data === "string" ? body.image_data : "";
    const mimeType = typeof body.mime_type === "string" ? body.mime_type : "image/jpeg";
    if (!description && !imageData) {
      return Response.json({ error: "أرسل وصف الوجبة أو صورتها." }, { status: 400 });
    }

    const parts = [{
      text: imageData
        ? `أنت خبير تغذية. حلّل صورة الطعام بدقة.\n${RULES}\n${note ? `ملاحظة المستخدم: ${note}` : ""}`
        : `أنت خبير تغذية. وصف المستخدم وجبته: "${description}".\n${RULES}\nإذا لم يذكر الكمية، افترض حصة معتادة متوسطة لشخص بالغ.\n${note ? `ملاحظة إضافية: ${note}` : ""}`
    }];
    if (imageData) {
      const match = imageData.match(/^data:([^;,]+);base64,(.+)$/);
      if (match) {
        parts.push({ inline_data: { mime_type: match[1] || mimeType, data: match[2] } });
      } else {
        parts.push({ inline_data: { mime_type: mimeType, data: imageData } });
      }
    }

    const response = await fetch(`${ENDPOINT}/${MODEL}:generateContent`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
      body: JSON.stringify({
        contents: [{ role: "user", parts }],
        generationConfig: { temperature: 0.35, maxOutputTokens: 2048, responseMimeType: "application/json", responseSchema: SCHEMA }
      })
    });
    const data = await response.json();
    if (!response.ok) {
      return Response.json({ error: data?.error?.message || `Gemini API error (${response.status})` }, { status: response.status });
    }
    const output = (data.candidates?.[0]?.content?.parts || []).filter(p => p && p.thought !== true).map(p => p.text || "").join("").trim();
    if (!output) return Response.json({ error: "لم يصل رد من Gemini، حاول مرة أخرى." }, { status: 502 });
    const result = JSON.parse(output.replace(/^```(?:json)?/i, "").replace(/```$/, "").trim());
    const items = Array.isArray(result.items) ? result.items : [];
    const totals = items.reduce((a, item) => {
      for (const key of ["calories", "protein", "carbs", "fat"]) a[key] += Number(item[key]) || 0;
      return a;
    }, { calories: 0, protein: 0, carbs: 0, fat: 0 });
    return Response.json({
      meal_name: result.meal_name || "وجبة",
      note: result.note || "",
      items: items.map(item => ({
        name: String(item.name || "عنصر"), quantity: String(item.quantity || ""),
        grams: Math.round(Number(item.grams) || 0), calories: Math.round(Number(item.calories) || 0),
        protein: Math.round(Number(item.protein) || 0), carbs: Math.round(Number(item.carbs) || 0),
        fat: Math.round(Number(item.fat) || 0)
      })),
      totals: Object.fromEntries(Object.entries(totals).map(([k, v]) => [k, Math.round(v)]))
    });
  } catch (error) {
    return Response.json({ error: error.message || "حدث خطأ أثناء تحليل الوجبة." }, { status: 500 });
  }
}
