const MODEL = "gemini-2.5-flash";
export async function onRequestPost({ request, env }) {
  try {
    if (!env.GEMINI_API_KEY) {
      return Response.json({ error: "مفتاح Gemini غير مضبوط في Cloudflare." }, { status: 500 });
    }
    const body = await request.json();
    const message = typeof body.message === "string" ? body.message.trim().slice(0, 1000) : "";
    if (!message) return Response.json({ error: "اكتب سؤالك أولاً." }, { status: 400 });
    const context = typeof body.context === "string" ? body.context.slice(0, 4000) : "";
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: `أنت "آيبي" المدرب الذكي في تطبيق I PROUD OF YOU للتغذية واللياقة وبناء العضلات. تحدث بالعربية الفصحى المبسطة بأسلوب ودود ومحفّز ومباشر. أجب بإيجاز من 2 إلى 6 أسطر، واقترح خطوة عملية واحدة. لا تقدم تشخيصاً طبياً ولا تختلق بيانات شخصية أو أرقاماً.\n\nبيانات متاحة عن المستخدم:\n${context || "لا توجد بيانات شخصية متاحة حالياً."}\n\nسؤال المستخدم: ${message}` }] }],
        generationConfig: { temperature: 0.7, maxOutputTokens: 1024 }
      })
    });
    const data = await response.json();
    if (!response.ok) return Response.json({ error: data?.error?.message || `Gemini API error (${response.status})` }, { status: response.status });
    const reply = (data.candidates?.[0]?.content?.parts || []).filter(p => p && p.thought !== true).map(p => p.text || "").join("").trim();
    if (!reply) return Response.json({ error: "لم يصل رد من آيبي، حاول مرة أخرى." }, { status: 502 });
    return Response.json({ reply });
  } catch (error) {
    return Response.json({ error: error.message || "حدث خطأ أثناء الاتصال بالمدرب." }, { status: 500 });
  }
}
